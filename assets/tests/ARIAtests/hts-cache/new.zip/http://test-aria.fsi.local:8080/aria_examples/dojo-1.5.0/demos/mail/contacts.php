{ 
	identifier: 'email',
	label: 'display',
	items: [

{ first: 'Adam',
last: 'Arkin',
email: 'adam.arkin@gmail.com',
display: 'Adam Arkin <adam.arkin@gmail.com>'
},
{ first: 'Adam',
last: 'DeBois',
email: 'adam.debois@yahoo.com',
display: 'Adam DeBois <adam.debois@yahoo.com>'
},
{ first: 'Adam',
last: 'Jones',
email: 'adam.jones@dojotoolkit.org',
display: 'Adam Jones <adam.jones@dojotoolkit.org>'
},
{ first: 'Adam',
last: 'Smith',
email: 'adam.smith@gmail.com',
display: 'Adam Smith <adam.smith@gmail.com>'
},
{ first: 'Adam',
last: 'Pitt',
email: 'adam.pitt@yahoo.com',
display: 'Adam Pitt <adam.pitt@yahoo.com>'
},
{ first: 'Adam',
last: 'Arquette',
email: 'adam.arquette@dojotoolkit.org',
display: 'Adam Arquette <adam.arquette@dojotoolkit.org>'
},
{ first: 'Adam',
last: 'VanDeLay',
email: 'adam.vandelay@gmail.com',
display: 'Adam VanDeLay <adam.vandelay@gmail.com>'
},
{ first: 'Alan',
last: 'Arkin',
email: 'alan.arkin@yahoo.com',
display: 'Alan Arkin <alan.arkin@yahoo.com>'
},
{ first: 'Alan',
last: 'DeBois',
email: 'alan.debois@dojotoolkit.org',
display: 'Alan DeBois <alan.debois@dojotoolkit.org>'
},
{ first: 'Alan',
last: 'Jones',
email: 'alan.jones@gmail.com',
display: 'Alan Jones <alan.jones@gmail.com>'
},
{ first: 'Alan',
last: 'Smith',
email: 'alan.smith@yahoo.com',
display: 'Alan Smith <alan.smith@yahoo.com>'
},
{ first: 'Alan',
last: 'Pitt',
email: 'alan.pitt@dojotoolkit.org',
display: 'Alan Pitt <alan.pitt@dojotoolkit.org>'
},
{ first: 'Alan',
last: 'Arquette',
email: 'alan.arquette@gmail.com',
display: 'Alan Arquette <alan.arquette@gmail.com>'
},
{ first: 'Alan',
last: 'VanDeLay',
email: 'alan.vandelay@yahoo.com',
display: 'Alan VanDeLay <alan.vandelay@yahoo.com>'
},
{ first: 'Alex',
last: 'Arkin',
email: 'alex.arkin@dojotoolkit.org',
display: 'Alex Arkin <alex.arkin@dojotoolkit.org>'
},
{ first: 'Alex',
last: 'DeBois',
email: 'alex.debois@gmail.com',
display: 'Alex DeBois <alex.debois@gmail.com>'
},
{ first: 'Alex',
last: 'Jones',
email: 'alex.jones@yahoo.com',
display: 'Alex Jones <alex.jones@yahoo.com>'
},
{ first: 'Alex',
last: 'Smith',
email: 'alex.smith@dojotoolkit.org',
display: 'Alex Smith <alex.smith@dojotoolkit.org>'
},
{ first: 'Alex',
last: 'Pitt',
email: 'alex.pitt@gmail.com',
display: 'Alex Pitt <alex.pitt@gmail.com>'
},
{ first: 'Alex',
last: 'Arquette',
email: 'alex.arquette@yahoo.com',
display: 'Alex Arquette <alex.arquette@yahoo.com>'
},
{ first: 'Alex',
last: 'VanDeLay',
email: 'alex.vandelay@dojotoolkit.org',
display: 'Alex VanDeLay <alex.vandelay@dojotoolkit.org>'
},
{ first: 'Bill',
last: 'Arkin',
email: 'bill.arkin@gmail.com',
display: 'Bill Arkin <bill.arkin@gmail.com>'
},
{ first: 'Bill',
last: 'DeBois',
email: 'bill.debois@yahoo.com',
display: 'Bill DeBois <bill.debois@yahoo.com>'
},
{ first: 'Bill',
last: 'Jones',
email: 'bill.jones@dojotoolkit.org',
display: 'Bill Jones <bill.jones@dojotoolkit.org>'
},
{ first: 'Bill',
last: 'Smith',
email: 'bill.smith@gmail.com',
display: 'Bill Smith <bill.smith@gmail.com>'
},
{ first: 'Bill',
last: 'Pitt',
email: 'bill.pitt@yahoo.com',
display: 'Bill Pitt <bill.pitt@yahoo.com>'
},
{ first: 'Bill',
last: 'Arquette',
email: 'bill.arquette@dojotoolkit.org',
display: 'Bill Arquette <bill.arquette@dojotoolkit.org>'
},
{ first: 'Bill',
last: 'VanDeLay',
email: 'bill.vandelay@gmail.com',
display: 'Bill VanDeLay <bill.vandelay@gmail.com>'
},
{ first: 'Becky',
last: 'Arkin',
email: 'becky.arkin@yahoo.com',
display: 'Becky Arkin <becky.arkin@yahoo.com>'
},
{ first: 'Becky',
last: 'DeBois',
email: 'becky.debois@dojotoolkit.org',
display: 'Becky DeBois <becky.debois@dojotoolkit.org>'
},
{ first: 'Becky',
last: 'Jones',
email: 'becky.jones@gmail.com',
display: 'Becky Jones <becky.jones@gmail.com>'
},
{ first: 'Becky',
last: 'Smith',
email: 'becky.smith@yahoo.com',
display: 'Becky Smith <becky.smith@yahoo.com>'
},
{ first: 'Becky',
last: 'Pitt',
email: 'becky.pitt@dojotoolkit.org',
display: 'Becky Pitt <becky.pitt@dojotoolkit.org>'
},
{ first: 'Becky',
last: 'Arquette',
email: 'becky.arquette@gmail.com',
display: 'Becky Arquette <becky.arquette@gmail.com>'
},
{ first: 'Becky',
last: 'VanDeLay',
email: 'becky.vandelay@yahoo.com',
display: 'Becky VanDeLay <becky.vandelay@yahoo.com>'
},
{ first: 'Bob',
last: 'Arkin',
email: 'bob.arkin@dojotoolkit.org',
display: 'Bob Arkin <bob.arkin@dojotoolkit.org>'
},
{ first: 'Bob',
last: 'DeBois',
email: 'bob.debois@gmail.com',
display: 'Bob DeBois <bob.debois@gmail.com>'
},
{ first: 'Bob',
last: 'Jones',
email: 'bob.jones@yahoo.com',
display: 'Bob Jones <bob.jones@yahoo.com>'
},
{ first: 'Bob',
last: 'Smith',
email: 'bob.smith@dojotoolkit.org',
display: 'Bob Smith <bob.smith@dojotoolkit.org>'
},
{ first: 'Bob',
last: 'Pitt',
email: 'bob.pitt@gmail.com',
display: 'Bob Pitt <bob.pitt@gmail.com>'
},
{ first: 'Bob',
last: 'Arquette',
email: 'bob.arquette@yahoo.com',
display: 'Bob Arquette <bob.arquette@yahoo.com>'
},
{ first: 'Bob',
last: 'VanDeLay',
email: 'bob.vandelay@dojotoolkit.org',
display: 'Bob VanDeLay <bob.vandelay@dojotoolkit.org>'
},
{ first: 'Bruce',
last: 'Arkin',
email: 'bruce.arkin@gmail.com',
display: 'Bruce Arkin <bruce.arkin@gmail.com>'
},
{ first: 'Bruce',
last: 'DeBois',
email: 'bruce.debois@yahoo.com',
display: 'Bruce DeBois <bruce.debois@yahoo.com>'
},
{ first: 'Bruce',
last: 'Jones',
email: 'bruce.jones@dojotoolkit.org',
display: 'Bruce Jones <bruce.jones@dojotoolkit.org>'
},
{ first: 'Bruce',
last: 'Smith',
email: 'bruce.smith@gmail.com',
display: 'Bruce Smith <bruce.smith@gmail.com>'
},
{ first: 'Bruce',
last: 'Pitt',
email: 'bruce.pitt@yahoo.com',
display: 'Bruce Pitt <bruce.pitt@yahoo.com>'
},
{ first: 'Bruce',
last: 'Arquette',
email: 'bruce.arquette@dojotoolkit.org',
display: 'Bruce Arquette <bruce.arquette@dojotoolkit.org>'
},
{ first: 'Bruce',
last: 'VanDeLay',
email: 'bruce.vandelay@gmail.com',
display: 'Bruce VanDeLay <bruce.vandelay@gmail.com>'
},
{ first: 'Carol',
last: 'Arkin',
email: 'carol.arkin@yahoo.com',
display: 'Carol Arkin <carol.arkin@yahoo.com>'
},
{ first: 'Carol',
last: 'DeBois',
email: 'carol.debois@dojotoolkit.org',
display: 'Carol DeBois <carol.debois@dojotoolkit.org>'
},
{ first: 'Carol',
last: 'Jones',
email: 'carol.jones@gmail.com',
display: 'Carol Jones <carol.jones@gmail.com>'
},
{ first: 'Carol',
last: 'Smith',
email: 'carol.smith@yahoo.com',
display: 'Carol Smith <carol.smith@yahoo.com>'
},
{ first: 'Carol',
last: 'Pitt',
email: 'carol.pitt@dojotoolkit.org',
display: 'Carol Pitt <carol.pitt@dojotoolkit.org>'
},
{ first: 'Carol',
last: 'Arquette',
email: 'carol.arquette@gmail.com',
display: 'Carol Arquette <carol.arquette@gmail.com>'
},
{ first: 'Carol',
last: 'VanDeLay',
email: 'carol.vandelay@yahoo.com',
display: 'Carol VanDeLay <carol.vandelay@yahoo.com>'
},
{ first: 'Chris',
last: 'Arkin',
email: 'chris.arkin@dojotoolkit.org',
display: 'Chris Arkin <chris.arkin@dojotoolkit.org>'
},
{ first: 'Chris',
last: 'DeBois',
email: 'chris.debois@gmail.com',
display: 'Chris DeBois <chris.debois@gmail.com>'
},
{ first: 'Chris',
last: 'Jones',
email: 'chris.jones@yahoo.com',
display: 'Chris Jones <chris.jones@yahoo.com>'
},
{ first: 'Chris',
last: 'Smith',
email: 'chris.smith@dojotoolkit.org',
display: 'Chris Smith <chris.smith@dojotoolkit.org>'
},
{ first: 'Chris',
last: 'Pitt',
email: 'chris.pitt@gmail.com',
display: 'Chris Pitt <chris.pitt@gmail.com>'
},
{ first: 'Chris',
last: 'Arquette',
email: 'chris.arquette@yahoo.com',
display: 'Chris Arquette <chris.arquette@yahoo.com>'
},
{ first: 'Chris',
last: 'VanDeLay',
email: 'chris.vandelay@dojotoolkit.org',
display: 'Chris VanDeLay <chris.vandelay@dojotoolkit.org>'
},
{ first: 'Dave',
last: 'Arkin',
email: 'dave.arkin@gmail.com',
display: 'Dave Arkin <dave.arkin@gmail.com>'
},
{ first: 'Dave',
last: 'DeBois',
email: 'dave.debois@yahoo.com',
display: 'Dave DeBois <dave.debois@yahoo.com>'
},
{ first: 'Dave',
last: 'Jones',
email: 'dave.jones@dojotoolkit.org',
display: 'Dave Jones <dave.jones@dojotoolkit.org>'
},
{ first: 'Dave',
last: 'Smith',
email: 'dave.smith@gmail.com',
display: 'Dave Smith <dave.smith@gmail.com>'
},
{ first: 'Dave',
last: 'Pitt',
email: 'dave.pitt@yahoo.com',
display: 'Dave Pitt <dave.pitt@yahoo.com>'
},
{ first: 'Dave',
last: 'Arquette',
email: 'dave.arquette@dojotoolkit.org',
display: 'Dave Arquette <dave.arquette@dojotoolkit.org>'
},
{ first: 'Dave',
last: 'VanDeLay',
email: 'dave.vandelay@gmail.com',
display: 'Dave VanDeLay <dave.vandelay@gmail.com>'
},
{ first: 'Ed',
last: 'Arkin',
email: 'ed.arkin@yahoo.com',
display: 'Ed Arkin <ed.arkin@yahoo.com>'
},
{ first: 'Ed',
last: 'DeBois',
email: 'ed.debois@dojotoolkit.org',
display: 'Ed DeBois <ed.debois@dojotoolkit.org>'
},
{ first: 'Ed',
last: 'Jones',
email: 'ed.jones@gmail.com',
display: 'Ed Jones <ed.jones@gmail.com>'
},
{ first: 'Ed',
last: 'Smith',
email: 'ed.smith@yahoo.com',
display: 'Ed Smith <ed.smith@yahoo.com>'
},
{ first: 'Ed',
last: 'Pitt',
email: 'ed.pitt@dojotoolkit.org',
display: 'Ed Pitt <ed.pitt@dojotoolkit.org>'
},
{ first: 'Ed',
last: 'Arquette',
email: 'ed.arquette@gmail.com',
display: 'Ed Arquette <ed.arquette@gmail.com>'
},
{ first: 'Ed',
last: 'VanDeLay',
email: 'ed.vandelay@yahoo.com',
display: 'Ed VanDeLay <ed.vandelay@yahoo.com>'
},
{ first: 'Ellen',
last: 'Arkin',
email: 'ellen.arkin@dojotoolkit.org',
display: 'Ellen Arkin <ellen.arkin@dojotoolkit.org>'
},
{ first: 'Ellen',
last: 'DeBois',
email: 'ellen.debois@gmail.com',
display: 'Ellen DeBois <ellen.debois@gmail.com>'
},
{ first: 'Ellen',
last: 'Jones',
email: 'ellen.jones@yahoo.com',
display: 'Ellen Jones <ellen.jones@yahoo.com>'
},
{ first: 'Ellen',
last: 'Smith',
email: 'ellen.smith@dojotoolkit.org',
display: 'Ellen Smith <ellen.smith@dojotoolkit.org>'
},
{ first: 'Ellen',
last: 'Pitt',
email: 'ellen.pitt@gmail.com',
display: 'Ellen Pitt <ellen.pitt@gmail.com>'
},
{ first: 'Ellen',
last: 'Arquette',
email: 'ellen.arquette@yahoo.com',
display: 'Ellen Arquette <ellen.arquette@yahoo.com>'
},
{ first: 'Ellen',
last: 'VanDeLay',
email: 'ellen.vandelay@dojotoolkit.org',
display: 'Ellen VanDeLay <ellen.vandelay@dojotoolkit.org>'
},
{ first: 'Eugene',
last: 'Arkin',
email: 'eugene.arkin@gmail.com',
display: 'Eugene Arkin <eugene.arkin@gmail.com>'
},
{ first: 'Eugene',
last: 'DeBois',
email: 'eugene.debois@yahoo.com',
display: 'Eugene DeBois <eugene.debois@yahoo.com>'
},
{ first: 'Eugene',
last: 'Jones',
email: 'eugene.jones@dojotoolkit.org',
display: 'Eugene Jones <eugene.jones@dojotoolkit.org>'
},
{ first: 'Eugene',
last: 'Smith',
email: 'eugene.smith@gmail.com',
display: 'Eugene Smith <eugene.smith@gmail.com>'
},
{ first: 'Eugene',
last: 'Pitt',
email: 'eugene.pitt@yahoo.com',
display: 'Eugene Pitt <eugene.pitt@yahoo.com>'
},
{ first: 'Eugene',
last: 'Arquette',
email: 'eugene.arquette@dojotoolkit.org',
display: 'Eugene Arquette <eugene.arquette@dojotoolkit.org>'
},
{ first: 'Eugene',
last: 'VanDeLay',
email: 'eugene.vandelay@gmail.com',
display: 'Eugene VanDeLay <eugene.vandelay@gmail.com>'
},
{ first: 'Frank',
last: 'Arkin',
email: 'frank.arkin@yahoo.com',
display: 'Frank Arkin <frank.arkin@yahoo.com>'
},
{ first: 'Frank',
last: 'DeBois',
email: 'frank.debois@dojotoolkit.org',
display: 'Frank DeBois <frank.debois@dojotoolkit.org>'
},
{ first: 'Frank',
last: 'Jones',
email: 'frank.jones@gmail.com',
display: 'Frank Jones <frank.jones@gmail.com>'
},
{ first: 'Frank',
last: 'Smith',
email: 'frank.smith@yahoo.com',
display: 'Frank Smith <frank.smith@yahoo.com>'
},
{ first: 'Frank',
last: 'Pitt',
email: 'frank.pitt@dojotoolkit.org',
display: 'Frank Pitt <frank.pitt@dojotoolkit.org>'
},
{ first: 'Frank',
last: 'Arquette',
email: 'frank.arquette@gmail.com',
display: 'Frank Arquette <frank.arquette@gmail.com>'
},
{ first: 'Frank',
last: 'VanDeLay',
email: 'frank.vandelay@yahoo.com',
display: 'Frank VanDeLay <frank.vandelay@yahoo.com>'
},
{ first: 'Fred',
last: 'Arkin',
email: 'fred.arkin@dojotoolkit.org',
display: 'Fred Arkin <fred.arkin@dojotoolkit.org>'
},
{ first: 'Fred',
last: 'DeBois',
email: 'fred.debois@gmail.com',
display: 'Fred DeBois <fred.debois@gmail.com>'
},
{ first: 'Fred',
last: 'Jones',
email: 'fred.jones@yahoo.com',
display: 'Fred Jones <fred.jones@yahoo.com>'
},
{ first: 'Fred',
last: 'Smith',
email: 'fred.smith@dojotoolkit.org',
display: 'Fred Smith <fred.smith@dojotoolkit.org>'
},
{ first: 'Fred',
last: 'Pitt',
email: 'fred.pitt@gmail.com',
display: 'Fred Pitt <fred.pitt@gmail.com>'
},
{ first: 'Fred',
last: 'Arquette',
email: 'fred.arquette@yahoo.com',
display: 'Fred Arquette <fred.arquette@yahoo.com>'
},
{ first: 'Fred',
last: 'VanDeLay',
email: 'fred.vandelay@dojotoolkit.org',
display: 'Fred VanDeLay <fred.vandelay@dojotoolkit.org>'
},
{ first: 'Francis',
last: 'Arkin',
email: 'francis.arkin@gmail.com',
display: 'Francis Arkin <francis.arkin@gmail.com>'
},
{ first: 'Francis',
last: 'DeBois',
email: 'francis.debois@yahoo.com',
display: 'Francis DeBois <francis.debois@yahoo.com>'
},
{ first: 'Francis',
last: 'Jones',
email: 'francis.jones@dojotoolkit.org',
display: 'Francis Jones <francis.jones@dojotoolkit.org>'
},
{ first: 'Francis',
last: 'Smith',
email: 'francis.smith@gmail.com',
display: 'Francis Smith <francis.smith@gmail.com>'
},
{ first: 'Francis',
last: 'Pitt',
email: 'francis.pitt@yahoo.com',
display: 'Francis Pitt <francis.pitt@yahoo.com>'
},
{ first: 'Francis',
last: 'Arquette',
email: 'francis.arquette@dojotoolkit.org',
display: 'Francis Arquette <francis.arquette@dojotoolkit.org>'
},
{ first: 'Francis',
last: 'VanDeLay',
email: 'francis.vandelay@gmail.com',
display: 'Francis VanDeLay <francis.vandelay@gmail.com>'
},
{ first: 'Glenn',
last: 'Arkin',
email: 'glenn.arkin@yahoo.com',
display: 'Glenn Arkin <glenn.arkin@yahoo.com>'
},
{ first: 'Glenn',
last: 'DeBois',
email: 'glenn.debois@dojotoolkit.org',
display: 'Glenn DeBois <glenn.debois@dojotoolkit.org>'
},
{ first: 'Glenn',
last: 'Jones',
email: 'glenn.jones@gmail.com',
display: 'Glenn Jones <glenn.jones@gmail.com>'
},
{ first: 'Glenn',
last: 'Smith',
email: 'glenn.smith@yahoo.com',
display: 'Glenn Smith <glenn.smith@yahoo.com>'
},
{ first: 'Glenn',
last: 'Pitt',
email: 'glenn.pitt@dojotoolkit.org',
display: 'Glenn Pitt <glenn.pitt@dojotoolkit.org>'
},
{ first: 'Glenn',
last: 'Arquette',
email: 'glenn.arquette@gmail.com',
display: 'Glenn Arquette <glenn.arquette@gmail.com>'
},
{ first: 'Glenn',
last: 'VanDeLay',
email: 'glenn.vandelay@yahoo.com',
display: 'Glenn VanDeLay <glenn.vandelay@yahoo.com>'
},
{ first: 'James',
last: 'Arkin',
email: 'james.arkin@dojotoolkit.org',
display: 'James Arkin <james.arkin@dojotoolkit.org>'
},
{ first: 'James',
last: 'DeBois',
email: 'james.debois@gmail.com',
display: 'James DeBois <james.debois@gmail.com>'
},
{ first: 'James',
last: 'Jones',
email: 'james.jones@yahoo.com',
display: 'James Jones <james.jones@yahoo.com>'
},
{ first: 'James',
last: 'Smith',
email: 'james.smith@dojotoolkit.org',
display: 'James Smith <james.smith@dojotoolkit.org>'
},
{ first: 'James',
last: 'Pitt',
email: 'james.pitt@gmail.com',
display: 'James Pitt <james.pitt@gmail.com>'
},
{ first: 'James',
last: 'Arquette',
email: 'james.arquette@yahoo.com',
display: 'James Arquette <james.arquette@yahoo.com>'
},
{ first: 'James',
last: 'VanDeLay',
email: 'james.vandelay@dojotoolkit.org',
display: 'James VanDeLay <james.vandelay@dojotoolkit.org>'
},
{ first: 'Jane',
last: 'Arkin',
email: 'jane.arkin@gmail.com',
display: 'Jane Arkin <jane.arkin@gmail.com>'
},
{ first: 'Jane',
last: 'DeBois',
email: 'jane.debois@yahoo.com',
display: 'Jane DeBois <jane.debois@yahoo.com>'
},
{ first: 'Jane',
last: 'Jones',
email: 'jane.jones@dojotoolkit.org',
display: 'Jane Jones <jane.jones@dojotoolkit.org>'
},
{ first: 'Jane',
last: 'Smith',
email: 'jane.smith@gmail.com',
display: 'Jane Smith <jane.smith@gmail.com>'
},
{ first: 'Jane',
last: 'Pitt',
email: 'jane.pitt@yahoo.com',
display: 'Jane Pitt <jane.pitt@yahoo.com>'
},
{ first: 'Jane',
last: 'Arquette',
email: 'jane.arquette@dojotoolkit.org',
display: 'Jane Arquette <jane.arquette@dojotoolkit.org>'
},
{ first: 'Jane',
last: 'VanDeLay',
email: 'jane.vandelay@gmail.com',
display: 'Jane VanDeLay <jane.vandelay@gmail.com>'
},
{ first: 'Joe',
last: 'Arkin',
email: 'joe.arkin@yahoo.com',
display: 'Joe Arkin <joe.arkin@yahoo.com>'
},
{ first: 'Joe',
last: 'DeBois',
email: 'joe.debois@dojotoolkit.org',
display: 'Joe DeBois <joe.debois@dojotoolkit.org>'
},
{ first: 'Joe',
last: 'Jones',
email: 'joe.jones@gmail.com',
display: 'Joe Jones <joe.jones@gmail.com>'
},
{ first: 'Joe',
last: 'Smith',
email: 'joe.smith@yahoo.com',
display: 'Joe Smith <joe.smith@yahoo.com>'
},
{ first: 'Joe',
last: 'Pitt',
email: 'joe.pitt@dojotoolkit.org',
display: 'Joe Pitt <joe.pitt@dojotoolkit.org>'
},
{ first: 'Joe',
last: 'Arquette',
email: 'joe.arquette@gmail.com',
display: 'Joe Arquette <joe.arquette@gmail.com>'
},
{ first: 'Joe',
last: 'VanDeLay',
email: 'joe.vandelay@yahoo.com',
display: 'Joe VanDeLay <joe.vandelay@yahoo.com>'
},
{ first: 'Tom',
last: 'Arkin',
email: 'tom.arkin@dojotoolkit.org',
display: 'Tom Arkin <tom.arkin@dojotoolkit.org>'
},
{ first: 'Tom',
last: 'DeBois',
email: 'tom.debois@gmail.com',
display: 'Tom DeBois <tom.debois@gmail.com>'
},
{ first: 'Tom',
last: 'Jones',
email: 'tom.jones@yahoo.com',
display: 'Tom Jones <tom.jones@yahoo.com>'
},
{ first: 'Tom',
last: 'Smith',
email: 'tom.smith@dojotoolkit.org',
display: 'Tom Smith <tom.smith@dojotoolkit.org>'
},
{ first: 'Tom',
last: 'Pitt',
email: 'tom.pitt@gmail.com',
display: 'Tom Pitt <tom.pitt@gmail.com>'
},
{ first: 'Tom',
last: 'Arquette',
email: 'tom.arquette@yahoo.com',
display: 'Tom Arquette <tom.arquette@yahoo.com>'
},
{ first: 'Tom',
last: 'VanDeLay',
email: 'tom.vandelay@dojotoolkit.org',
display: 'Tom VanDeLay <tom.vandelay@dojotoolkit.org>'
},
	{name: 'Blue Bell', email: 'blue.bell@gmail.com'}
   ]
}
